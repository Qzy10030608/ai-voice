import os
import sys
import time
import uuid
import sounddevice as sd
import soundfile as sf

from PySide6.QtCore import QUrl, QObject, Signal, QThread
from PySide6.QtWidgets import QApplication, QMessageBox
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput

# 导入配置
from config import (
    APP_TITLE,
    RECORD_FOLDER,
    REPLY_FOLDER,
    CACHE_FOLDER,
    SAMPLE_RATE,
    CHANNELS,
    RECORD_DTYPE,
    MIN_RECORD_SECONDS,
    MAX_RECORD_SECONDS,
    RECORD_EXTENSION,
    TTS_OUTPUT_EXTENSION,
    TTS_VOICE,
    AUTO_PLAY_AUDIO,
    DEFAULT_SPEECH_RATE
)

# 导入服务层
from services.llm_service import chat_with_ollama
from services.asr_service import transcribe_audio
from services.tts_service import text_to_speech

# 导入页面
from ui.main_window import MainWindow


# =========================
# 后台线程 Worker
# =========================
class ChatWorker(QObject):
    finished = Signal(int, str, str)   # request_id, user_text, ai_text
    error = Signal(int, str)

    def __init__(self, request_id: int, text: str, history: list):
        super().__init__()
        self.request_id = request_id
        self.text = text
        self.history = history

    def run(self):
        try:
            ai_text = chat_with_ollama(self.text, history=self.history)
            self.finished.emit(self.request_id, self.text, ai_text)
        except Exception as e:
            self.error.emit(self.request_id, str(e))


class ASRWorker(QObject):
    finished = Signal(int, str)   # request_id, recognized_text
    error = Signal(int, str)

    def __init__(self, request_id: int, record_path: str):
        super().__init__()
        self.request_id = request_id
        self.record_path = record_path

    def run(self):
        try:
            recognized_text = transcribe_audio(self.record_path).strip()
            self.finished.emit(self.request_id, recognized_text)
        except Exception as e:
            self.error.emit(self.request_id, str(e))


class TTSWorker(QObject):
    finished = Signal(int, str)   # request_id, reply_path
    error = Signal(int, str)

    def __init__(self, request_id: int, ai_text: str, reply_folder: str, tts_ext: str, tts_voice: str):
        super().__init__()
        self.request_id = request_id
        self.ai_text = ai_text
        self.reply_folder = reply_folder
        self.tts_ext = tts_ext
        self.tts_voice = tts_voice

    def run(self):
        try:
            reply_filename = f"{uuid.uuid4().hex}{self.tts_ext}"
            reply_path = os.path.join(self.reply_folder, reply_filename)
            text_to_speech(self.ai_text, reply_path, self.tts_voice)
            self.finished.emit(self.request_id, reply_path)
        except Exception as e:
            self.error.emit(self.request_id, str(e))


# =========================
# 主控制器
# =========================
class DesktopAIController:
    """
    桌面版语音 AI 控制器
    """

    MAX_HISTORY_MESSAGES = 6

    def __init__(self):
        os.makedirs(RECORD_FOLDER, exist_ok=True)
        os.makedirs(REPLY_FOLDER, exist_ok=True)
        os.makedirs(CACHE_FOLDER, exist_ok=True)

        self.window = MainWindow()
        self.window.setWindowTitle(APP_TITLE)

        self.chat_history = []
        self.current_recognized_text = ""
        self.current_record_path = ""
        self.current_reply_audio_path = ""

        self.current_speech_rate = DEFAULT_SPEECH_RATE

        self.is_recording = False
        self.record_start_time = None
        self.record_buffer = None

        # 会话版本号：刷新后递增，避免旧线程结果污染新界面
        self.session_id = 0

        # -------------------------
        # 录音回放播放器
        # -------------------------
        self.record_audio_output = QAudioOutput()
        self.record_player = QMediaPlayer()
        self.record_player.setAudioOutput(self.record_audio_output)
        self.record_player.positionChanged.connect(self.on_record_position_changed)
        self.record_player.durationChanged.connect(self.on_record_duration_changed)
        self.record_player.playbackStateChanged.connect(self.on_record_playback_state_changed)

        # -------------------------
        # AI 回复播放器
        # -------------------------
        self.ai_audio_output = QAudioOutput()
        self.ai_player = QMediaPlayer()
        self.ai_player.setAudioOutput(self.ai_audio_output)
        self.ai_player.setPlaybackRate(self.current_speech_rate)

        # 线程引用
        self.chat_thread = None
        self.chat_worker = None
        self.asr_thread = None
        self.asr_worker = None
        self.tts_thread = None
        self.tts_worker = None

        self.bind_signals()

    # =========================
    # 信号绑定
    # =========================
    def bind_signals(self):
        self.window.send_text_requested.connect(self.handle_send_text)
        self.window.start_record_requested.connect(self.handle_start_record)
        self.window.stop_record_requested.connect(self.handle_stop_record)

        # 这里不再使用“发送语音识别结果给 AI”
        # self.window.send_recognized_requested.connect(self.handle_send_recognized_text)

        self.window.refresh_requested.connect(self.handle_refresh)
        self.window.exit_requested.connect(self.handle_exit)

        # 录音回放相关
        self.window.record_play_requested.connect(self.handle_record_play)
        self.window.record_pause_requested.connect(self.handle_record_pause)
        self.window.record_seek_requested.connect(self.handle_record_seek)
        self.window.record_speed_changed.connect(self.handle_record_speed_changed)

    # =========================
    # 公共小工具
    # =========================
    def _trim_history(self):
        self.chat_history = self.chat_history[-self.MAX_HISTORY_MESSAGES:]

    def _set_busy(self, busy: bool):
        """
        控制页面按钮状态，避免重复点击
        """
        self.window.send_text_btn.setEnabled(not busy)
        self.window.start_record_btn.setEnabled(not busy and not self.is_recording)

    def _start_chat_request(self, text: str, from_voice: bool = False):
        """
        启动后台聊天线程
        """
        text = text.strip()
        if not text:
            self.window.set_status("输入文本为空")
            return

        self._set_busy(True)

        if from_voice:
            self.window.set_status("语音识别完成，正在请求 AI 回复...")
        else:
            self.window.set_status("正在请求 AI 回复...")

        request_id = self.session_id

        self.chat_thread = QThread()
        self.chat_worker = ChatWorker(
            request_id=request_id,
            text=text,
            history=list(self.chat_history)
        )
        self.chat_worker.moveToThread(self.chat_thread)

        self.chat_thread.started.connect(self.chat_worker.run)
        self.chat_worker.finished.connect(self.on_chat_finished)
        self.chat_worker.error.connect(self.on_chat_error)

        self.chat_worker.finished.connect(self.chat_thread.quit)
        self.chat_worker.error.connect(self.chat_thread.quit)
        self.chat_worker.finished.connect(self.chat_worker.deleteLater)
        self.chat_worker.error.connect(self.chat_worker.deleteLater)
        self.chat_thread.finished.connect(self.chat_thread.deleteLater)

        self.chat_thread.start()

    def _start_tts_request(self, ai_text: str):
        """
        启动后台 TTS 线程
        """
        request_id = self.session_id

        self.tts_thread = QThread()
        self.tts_worker = TTSWorker(
            request_id=request_id,
            ai_text=ai_text,
            reply_folder=REPLY_FOLDER,
            tts_ext=TTS_OUTPUT_EXTENSION,
            tts_voice=TTS_VOICE
        )
        self.tts_worker.moveToThread(self.tts_thread)

        self.tts_thread.started.connect(self.tts_worker.run)
        self.tts_worker.finished.connect(self.on_tts_finished)
        self.tts_worker.error.connect(self.on_tts_error)

        self.tts_worker.finished.connect(self.tts_thread.quit)
        self.tts_worker.error.connect(self.tts_thread.quit)
        self.tts_worker.finished.connect(self.tts_worker.deleteLater)
        self.tts_worker.error.connect(self.tts_worker.deleteLater)
        self.tts_thread.finished.connect(self.tts_thread.deleteLater)

        self.tts_thread.start()

    # =========================
    # 文字聊天
    # =========================
    def handle_send_text(self, text: str):
        """
        发送文字给 AI（后台线程）
        """
        self._start_chat_request(text, from_voice=False)

    def on_chat_finished(self, request_id: int, user_text: str, ai_text: str):
        """
        LLM 返回完成：
        1. 先显示文字回复
        2. 再后台生成语音
        """
        if request_id != self.session_id:
            return

        self.chat_history.append({"role": "user", "content": user_text})
        self.chat_history.append({"role": "assistant", "content": ai_text})
        self._trim_history()

        self.window.append_ai_message(ai_text)
        self.window.set_status("AI 文字回复完成，正在后台生成语音...")
        self._set_busy(False)

        # 文字先出来，再后台生成语音
        self._start_tts_request(ai_text)

    def on_chat_error(self, request_id: int, msg: str):
        if request_id != self.session_id:
            return

        self._set_busy(False)
        self.window.set_status(f"聊天失败：{msg}")
        QMessageBox.critical(self.window, "错误", f"聊天失败：\n{msg}")

    # =========================
    # TTS 结果
    # =========================
    def on_tts_finished(self, request_id: int, reply_path: str):
        if request_id != self.session_id:
            return

        self.current_reply_audio_path = reply_path
        self.ai_player.setSource(QUrl.fromLocalFile(reply_path))
        self.ai_player.setPlaybackRate(self.current_speech_rate)

        if AUTO_PLAY_AUDIO:
            self.ai_player.play()

        self.window.set_status("AI 语音已生成")

    def on_tts_error(self, request_id: int, msg: str):
        if request_id != self.session_id:
            return

        # 这里不弹窗打断聊天，只更新状态
        self.window.set_status(f"AI 文字已回复，但语音生成失败：{msg}")

    # =========================
    # 录音
    # =========================
    def handle_start_record(self):
        """
        开始录音
        """
        if self.is_recording:
            self.window.set_status("当前已经在录音中")
            return

        try:
            self.window.set_status("正在启动录音...")
            self.record_start_time = time.time()

            total_frames = int(MAX_RECORD_SECONDS * SAMPLE_RATE)
            self.record_buffer = sd.rec(
                total_frames,
                samplerate=SAMPLE_RATE,
                channels=CHANNELS,
                dtype=RECORD_DTYPE
            )

            self.is_recording = True
            self.window.set_status("录音中...")
            self.window.start_record_btn.setEnabled(False)
            self.window.stop_record_btn.setEnabled(True)

        except Exception as e:
            self.is_recording = False
            self.record_start_time = None
            self.record_buffer = None
            self.window.set_status(f"开始录音失败：{str(e)}")
            QMessageBox.critical(self.window, "错误", f"开始录音失败：\n{str(e)}")

    def handle_stop_record(self):
        """
        停止录音并自动走：
        录音 -> ASR -> 直接发给 AI
        """
        if not self.is_recording:
            self.window.set_status("当前没有正在进行的录音")
            return

        try:
            sd.stop()

            elapsed = time.time() - self.record_start_time
            elapsed = max(0.0, min(elapsed, float(MAX_RECORD_SECONDS)))
            self.is_recording = False

            self.window.start_record_btn.setEnabled(True)
            self.window.stop_record_btn.setEnabled(False)

            if elapsed < MIN_RECORD_SECONDS:
                self.window.set_status(f"录音不足 {MIN_RECORD_SECONDS} 秒，请重新录音")
                self.current_record_path = ""
                self.current_recognized_text = ""
                return

            valid_frames = int(elapsed * SAMPLE_RATE)
            valid_audio = self.record_buffer[:valid_frames]

            record_filename = f"{uuid.uuid4().hex}{RECORD_EXTENSION}"
            record_path = os.path.join(RECORD_FOLDER, record_filename)
            sf.write(record_path, valid_audio, SAMPLE_RATE)

            self.current_record_path = record_path

            # 设置录音回放
            self.record_player.setSource(QUrl.fromLocalFile(record_path))
            self.record_player.setPlaybackRate(1.0)
            self.window.set_record_playback_enabled(True)
            self.window.set_record_play_state(False)
            self.window.update_record_playback_ui(0, 0)

            self.window.set_status("录音完成，正在后台识别语音...")
            self._set_busy(True)

            request_id = self.session_id

            self.asr_thread = QThread()
            self.asr_worker = ASRWorker(request_id=request_id, record_path=record_path)
            self.asr_worker.moveToThread(self.asr_thread)

            self.asr_thread.started.connect(self.asr_worker.run)
            self.asr_worker.finished.connect(self.on_asr_finished)
            self.asr_worker.error.connect(self.on_asr_error)

            self.asr_worker.finished.connect(self.asr_thread.quit)
            self.asr_worker.error.connect(self.asr_thread.quit)
            self.asr_worker.finished.connect(self.asr_worker.deleteLater)
            self.asr_worker.error.connect(self.asr_worker.deleteLater)
            self.asr_thread.finished.connect(self.asr_thread.deleteLater)

            self.asr_thread.start()

        except Exception as e:
            self.window.set_status(f"停止录音失败：{str(e)}")
            QMessageBox.critical(self.window, "错误", f"停止录音失败：\n{str(e)}")

        finally:
            self.record_start_time = None
            self.record_buffer = None

    # =========================
    # ASR 完成后，直接发给 AI
    # =========================
    def on_asr_finished(self, request_id: int, recognized_text: str):
        if request_id != self.session_id:
            return

        self.current_recognized_text = recognized_text.strip()

        if not self.current_recognized_text:
            self._set_busy(False)
            self.window.set_status("未识别到有效语音内容")
            QMessageBox.warning(self.window, "提示", "未识别到有效语音内容。")
            return

        # 聊天区显示识别结果
        self.window.set_recognized_text(self.current_recognized_text)

        # 不再需要“发送语音识别结果给 AI”按钮，直接后台发给 AI
        self._start_chat_request(self.current_recognized_text, from_voice=True)

    def on_asr_error(self, request_id: int, msg: str):
        if request_id != self.session_id:
            return

        self._set_busy(False)
        self.window.set_status(f"语音识别失败：{msg}")
        QMessageBox.critical(self.window, "错误", f"语音识别失败：\n{msg}")

    # =========================
    # 录音回放
    # =========================
    def handle_record_play(self):
        if not self.current_record_path:
            self.window.set_status("当前没有可回放的录音")
            return

        self.record_player.play()
        self.window.set_record_play_state(True)
        self.window.set_status("正在播放录音")

    def handle_record_pause(self):
        self.record_player.pause()
        self.window.set_record_play_state(False)
        self.window.set_status("已暂停录音播放")

    def handle_record_seek(self, progress: float):
        duration = self.record_player.duration()
        if duration <= 0:
            return
        position = int(duration * progress)
        self.record_player.setPosition(position)

    def handle_record_speed_changed(self, speed: float):
        self.record_player.setPlaybackRate(speed)
        self.window.set_status(f"录音回放速度已切换为 {speed}x")

    def on_record_position_changed(self, position: int):
        self.window.update_record_playback_ui(position)

    def on_record_duration_changed(self, duration: int):
        self.window.set_record_duration(duration)

    def on_record_playback_state_changed(self, state):
        if state == QMediaPlayer.PlayingState:
            self.window.set_record_play_state(True)
        else:
            self.window.set_record_play_state(False)

    # =========================
    # 刷新 / 退出
    # =========================
    def handle_refresh(self):
        """
        刷新页面
        """
        self.session_id += 1  # 旧线程结果全部失效

        self.record_player.stop()
        self.ai_player.stop()

        self.record_player.setPlaybackRate(1.0)

        self.current_recognized_text = ""
        self.current_record_path = ""
        self.current_reply_audio_path = ""
        self.chat_history = []

        self.window.clear_page()
        self.window.set_record_playback_enabled(False)
        self.window.set_record_play_state(False)
        self.window.update_record_playback_ui(0, 0)
        self.window.set_status("页面已刷新")

        self._set_busy(False)
        self.window.stop_record_btn.setEnabled(False)

    def handle_exit(self):
        """
        退出页面
        """
        try:
            self.session_id += 1

            if self.is_recording:
                sd.stop()
                self.is_recording = False

            self.record_player.stop()
            self.ai_player.stop()

        except Exception:
            pass

    def show(self):
        self.window.show()


def main():
    app = QApplication(sys.argv)
    controller = DesktopAIController()
    controller.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()