import ollama
from config import OLLAMA_MODEL, SYSTEM_PROMPT, MAX_HISTORY_MESSAGES


def build_messages(user_text, history=None):
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    if history:
        history = history[-MAX_HISTORY_MESSAGES:]
        messages.extend(history)

    messages.append({"role": "user", "content": user_text})
    return messages


def chat_with_ollama(user_text, history=None):
    messages = build_messages(user_text, history)

    response = ollama.chat(
        model=OLLAMA_MODEL,
        messages=messages
    )

    ai_text = response["message"]["content"].strip()
    return ai_text