from faster_whisper import WhisperModel
from config import WHISPER_MODEL_SIZE, WHISPER_DEVICE, WHISPER_COMPUTE_TYPE

_whisper_model = None


def get_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        _whisper_model = WhisperModel(
            WHISPER_MODEL_SIZE,
            device=WHISPER_DEVICE,
            compute_type=WHISPER_COMPUTE_TYPE
        )
    return _whisper_model


def transcribe_audio(audio_path):
    model = get_whisper_model()
    segments, info = model.transcribe(audio_path, language="zh")
    text = "".join(segment.text for segment in segments).strip()
    return text