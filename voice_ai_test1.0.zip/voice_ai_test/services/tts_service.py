import asyncio
import edge_tts


async def _generate_tts(text, output_file, voice):
    communicate = edge_tts.Communicate(text=text, voice=voice)
    await communicate.save(output_file)


def text_to_speech(text, output_file, voice):
    asyncio.run(_generate_tts(text, output_file, voice))