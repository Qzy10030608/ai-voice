import os

# =========================
# 基础路径配置（桌面版）
# =========================

# 当前 config.py 所在目录，通常就是项目根目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# 临时目录
TEMP_FOLDER = os.path.join(BASE_DIR, "temp")

# 录音文件保存目录（用户本地录音）
RECORD_FOLDER = os.path.join(TEMP_FOLDER, "records")

# AI 回复语音保存目录
REPLY_FOLDER = os.path.join(TEMP_FOLDER, "replies")

# 日志或其他缓存可扩展目录
CACHE_FOLDER = os.path.join(TEMP_FOLDER, "cache")


# =========================
# 桌面程序基础配置
# =========================

# 窗口标题
APP_TITLE = "本地桌面语音 AI 原型"

# 用户显示名称
USER_NAME = "用户"

# AI 显示名称
ASSISTANT_NAME = "语音AI助手"


# =========================
# Ollama / LLM 配置
# =========================

# 本地 Ollama 模型名称
OLLAMA_MODEL = "qwen3:4b"

# 系统提示词
SYSTEM_PROMPT = (
    "你是一个自然、温和、适合中文桌面对话的AI助手。"
    "请使用简洁、自然、偏口语的中文回答。"
    "回答不要过长，适合语音播放。"
)

# 最大上下文消息数（不含 system）
MAX_HISTORY_MESSAGES = 6


# =========================
# Whisper / ASR 配置
# =========================

# faster-whisper 模型大小
WHISPER_MODEL_SIZE = "base"

# 识别设备：cpu / cuda
WHISPER_DEVICE = "cuda"

# 识别精度：推荐 GPU 用 float16
WHISPER_COMPUTE_TYPE = "float16"

# 默认识别语言
ASR_LANGUAGE = "zh"


# =========================
# 录音配置（桌面版）
# =========================

# 录音采样率
SAMPLE_RATE = 16000

# 单声道
CHANNELS = 1

# 录音数据类型
RECORD_DTYPE = "float32"

# 最短录音时长（秒）
MIN_RECORD_SECONDS = 2

# 最长录音时长（秒）
MAX_RECORD_SECONDS = 60

# 默认录音文件扩展名
RECORD_EXTENSION = ".wav"


# =========================
# TTS 配置
# =========================

# edge-tts 声音
TTS_VOICE = "zh-CN-XiaoxiaoNeural"

# AI 回复语音输出格式
TTS_OUTPUT_EXTENSION = ".mp3"

# 是否自动播放 AI 回复
AUTO_PLAY_AUDIO = True

# 默认语速（页面滑条初始值）
DEFAULT_SPEECH_RATE = 1.0