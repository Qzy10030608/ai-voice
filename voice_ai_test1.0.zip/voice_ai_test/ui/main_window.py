import time

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QPlainTextEdit,
    QPushButton, QLabel, QProgressBar, QSlider, QMessageBox, QFrame, QMenu
)


class SendTextEdit(QPlainTextEdit):
    double_enter_send = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.last_enter_time = 0.0
        self.enter_interval = 0.4  # 秒

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            now = time.time()

            # 如果两次回车间隔很短，判定为“双击回车发送”
            if now - self.last_enter_time <= self.enter_interval:
                self.last_enter_time = 0.0
                self.double_enter_send.emit()
                event.accept()
                return

            # 第一次回车：正常换行
            self.last_enter_time = now
            super().keyPressEvent(event)
            return

        super().keyPressEvent(event)

class MainWindow(QWidget):
    """
    桌面版语音 AI 主页面

    说明：
    1. 本文件只负责界面与页面层交互。
    2. 不直接写 Whisper / Ollama / TTS 的底层实现。
    3. 通过信号把用户操作发给外部控制器或主程序。
    """

    # =========================
    # 对外信号定义
    # =========================

    # 发送文本给 AI
    send_text_requested = Signal(str)

    # 开始录音
    start_record_requested = Signal()

    # 停止录音
    stop_record_requested = Signal()

    # 刷新页面
    refresh_requested = Signal()

    # 退出程序
    exit_requested = Signal()

    # 语速变化信号，传递 float 类型，例如 1.0、1.2、0.8
    record_play_requested = Signal()
    record_pause_requested = Signal()
    record_seek_requested = Signal(float)   # 0.0 ~ 1.0
    record_speed_changed = Signal(float)

    def __init__(self):
        super().__init__()

        # 窗口基础设置
        self.setWindowTitle("本地桌面语音 AI 原型")
        self.resize(1000, 760)

        # 当前识别到的语音文本
        self.current_recognized_text = ""

        # 当前录音秒数
        self.record_seconds = 0

        # 最短录音时长（秒）
        self.min_record_seconds = 2

        # 最长录音时长（秒）
        self.max_record_seconds = 60

        # 录音定时器：每 1 秒更新时间
        self.record_timer = QTimer(self)
        self.record_timer.timeout.connect(self.update_record_progress)

        # 语速调节
        self.record_total_ms = 0
        self.record_current_ms = 0
        self.record_is_playing = False
        self.record_speed = 1.0

        # 初始化界面
        self.init_ui()
        # 初始化倍速菜单
        self.init_speed_menu()

    # =========================
    # 界面初始化
    # =========================
    def init_ui(self):
        """
        初始化页面布局
        """
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(18, 18, 18, 18)
        main_layout.setSpacing(14)

        # 页面标题
        title_label = QLabel("本地桌面语音 AI 测试界面")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setObjectName("titleLabel")
        main_layout.addWidget(title_label)
        self.main_card = QFrame()
        self.main_card.setObjectName("mainCard")

        card_layout = QVBoxLayout(self.main_card)
        card_layout.setContentsMargins(22, 22, 22, 22)
        card_layout.setSpacing(14)

        # -------------------------
        # 聊天显示区
        # -------------------------
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setPlaceholderText("这里显示用户输入、语音识别结果和 AI 回复...")
        self.chat_display.setObjectName("chatDisplay")
        card_layout.addWidget(self.chat_display, stretch=5)

        # -------------------------
        # 输入框标题
        # -------------------------
        input_label = QLabel("文本输入区，点击回车一次是换行，双击是发送")
        input_label.setObjectName("sectionLabel")
        card_layout.addWidget(input_label)

        # -------------------------
        # 文本输入框
        # -------------------------
        self.text_input = SendTextEdit()
        self.text_input.setPlaceholderText("请输入文字，或将语音识别结果发送给 AI...")
        self.text_input.setMaximumHeight(130)
        self.text_input.setObjectName("textInput")
        self.text_input.double_enter_send.connect(self.on_send_text_clicked)
        card_layout.addWidget(self.text_input, stretch=1)

        # -------------------------
        # 录音状态与进度显示区
        # -------------------------
        record_info_frame = QFrame()
        record_info_frame.setObjectName("infoBar")

        record_info_layout = QHBoxLayout(record_info_frame)
        record_info_layout.setContentsMargins(12, 10, 12, 10)
        record_info_layout.setSpacing(10)

        self.record_status_label = QLabel("录音状态：未开始")
        self.record_status_label.setObjectName("infoLabel")

        self.record_time_label = QLabel("录音时长：0 秒 / 60 秒")
        self.record_time_label.setObjectName("infoLabel")

        record_info_layout.addWidget(self.record_status_label)
        record_info_layout.addStretch()
        record_info_layout.addWidget(self.record_time_label)

        card_layout.addWidget(record_info_frame)

        # 录音进度条
        self.record_progress = QProgressBar()
        self.record_progress.setMinimum(0)
        self.record_progress.setMaximum(self.max_record_seconds)
        self.record_progress.setValue(0)
        self.record_progress.setTextVisible(True)
        self.record_progress.setFormat("录音进度：%v / %m 秒")
        self.record_progress.setObjectName("recordProgress")
        card_layout.addWidget(self.record_progress)

        # -------------------------
        # 录音回放区（替代原语速滑条区）
        # -------------------------
        self.record_playback_frame = QFrame()
        self.record_playback_frame.setObjectName("infoBar")
        record_playback_layout = QHBoxLayout(self.record_playback_frame)
        record_playback_layout.setContentsMargins(12, 10, 12, 10)
        record_playback_layout.setSpacing(10)

        self.record_playback_title = QLabel("录音回放：")
        self.record_playback_title.setObjectName("infoTextStrong")

        self.record_play_btn = QPushButton("▶")
        self.record_play_btn.setObjectName("iconButton")
        self.record_play_btn.setFixedWidth(42)
        self.record_play_btn.setEnabled(False)
        self.record_play_btn.clicked.connect(self.on_record_play_clicked)

        self.record_seek_slider = QSlider(Qt.Horizontal)
        self.record_seek_slider.setObjectName("recordSeekSlider")
        self.record_seek_slider.setMinimum(0)
        self.record_seek_slider.setMaximum(1000)
        self.record_seek_slider.setValue(0)
        self.record_seek_slider.setEnabled(False)
        self.record_seek_slider.sliderReleased.connect(self.on_record_seek_released)

        self.record_time_preview_label = QLabel("0:00 / 0:00")
        self.record_time_preview_label.setObjectName("recordTimeLabel")
        self.record_time_preview_label.setFixedWidth(90)
        self.record_time_preview_label.setAlignment(Qt.AlignCenter)

        self.speed_menu_btn = QPushButton("1.0x")
        self.speed_menu_btn.setObjectName("speedValueButton")
        self.speed_menu_btn.setFixedWidth(72)
        self.speed_menu_btn.setEnabled(False)

        record_playback_layout.addWidget(self.record_playback_title)
        record_playback_layout.addWidget(self.record_play_btn)
        record_playback_layout.addWidget(self.record_seek_slider, stretch=1)
        record_playback_layout.addWidget(self.record_time_preview_label)
        record_playback_layout.addWidget(self.speed_menu_btn)

        card_layout.addWidget(self.record_playback_frame)

        # -------------------------
        # 按钮区：第一排
        # -------------------------
        btn_row_1 = QHBoxLayout()
        btn_row_1.setSpacing(10)

        self.send_text_btn = QPushButton("发送文字")
        self.send_text_btn.clicked.connect(self.on_send_text_clicked)

        self.start_record_btn = QPushButton("开始录音")
        self.start_record_btn.clicked.connect(self.on_start_record_clicked)

        self.stop_record_btn = QPushButton("停止录音")
        self.stop_record_btn.setEnabled(False)
        self.stop_record_btn.clicked.connect(self.on_stop_record_clicked)

        btn_row_1.addWidget(self.send_text_btn)
        btn_row_1.addWidget(self.start_record_btn)
        btn_row_1.addWidget(self.stop_record_btn)

        card_layout.addLayout(btn_row_1)

        # -------------------------
        # 按钮区：第二排
        # -------------------------
        btn_row_2 = QHBoxLayout()
        btn_row_2.setSpacing(10)

        self.refresh_btn = QPushButton("刷新页面")
        self.refresh_btn.clicked.connect(self.on_refresh_clicked)

        self.exit_btn = QPushButton("退出页面")
        self.exit_btn.clicked.connect(self.on_exit_clicked)

        btn_row_2.addWidget(self.refresh_btn)
        btn_row_2.addWidget(self.exit_btn)

        card_layout.addLayout(btn_row_2)
        # -------------------------
        # 状态显示区
        # -------------------------
        self.status_label = QLabel("状态：等待操作")
        self.status_label.setObjectName("statusBar")
        main_layout.addWidget(self.status_label)
        main_layout.addWidget(self.main_card)
        self.setStyleSheet("""
        QWidget {
            background-color: #1E5AA8;
            color: #FFFFFF;
            font-family: "Microsoft YaHei";
            font-size: 14px;
        }

        QLabel#titleLabel {
            font-size: 24px;
            font-weight: bold;
            padding: 8px;
            color: #FFFFFF;
        }

        QLabel#sectionLabel {
            font-size: 15px;
            font-weight: bold;
            color: #FFFFFF;
            background: transparent;
        }

        QLabel#infoLabel {
            color: #FFFFFF;
            font-size: 14px;
            background: transparent;
        }

        QFrame#mainCard {
            background-color: #0B1835;
            border-radius: 18px;
            padding: 6px;
        }

        QTextEdit#chatDisplay {
            background-color: #000000;
            color: #FFD37A;
            border: 1px solid #16284D;
            border-radius: 12px;
            padding: 12px;
            font-size: 15px;
        }

        QPlainTextEdit#textInput {
            background-color: #657181;
            color: #FFFFFF;
            border: 1px solid #7D8796;
            border-radius: 12px;
            padding: 12px;
            font-size: 15px;
        }

        QProgressBar#recordProgress {
            border: 1px solid #1C2B4C;
            border-radius: 12px;
            text-align: center;
            height: 28px;
            background-color: #000000;
            color: #FFFFFF;
            font-weight: bold;
        }

        QProgressBar#recordProgress::chunk {
            background-color: #2F6FE4;
            border-radius: 12px;
        }

        QFrame#infoBar {
            background-color: #0A0A0A;
            border: 1px solid #24324F;
            border-radius: 12px;
        }

        QPushButton {
            background-color: #2F6FE4;
            color: #FFFFFF;
            border-radius: 10px;
            min-height: 42px;
            font-size: 15px;
            font-weight: bold;
            border: none;
        }

        QPushButton:hover {
            background-color: #4780EC;
        }

        QPushButton:disabled {
            background-color: #5E6A7C;
            color: #D1D5DB;
        }

        QPushButton#iconButton {
            background-color: #1E293B;
            color: #FFFFFF;
            border: 1px solid #475569;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 700;
            min-height: 34px;
        }

        QPushButton#iconButton:hover {
            background-color: #334155;
        }

        QPushButton#speedValueButton {
            background-color: #1E293B;
            color: #FFFFFF;
            border: 1px solid #475569;
            border-radius: 8px;
            padding: 4px 8px;
            font-size: 14px;
            font-weight: 700;
            min-height: 34px;
        }

        QPushButton#speedValueButton:hover {
            background-color: #334155;
        }

        QLabel#recordTimeLabel {
            color: #E2E8F0;
            font-size: 13px;
            font-weight: 600;
        }

        QLabel#statusBar {
            background-color: #071224;
            border: 1px solid #1B2E52;
            border-radius: 12px;
            padding: 10px;
            color: #DCE6F8;
        }

        QSlider#recordSeekSlider::groove:horizontal {
            height: 8px;
            background: #374151;
            border-radius: 4px;
        }

        QSlider#recordSeekSlider::sub-page:horizontal {
            background: #A855F7;
            border-radius: 4px;
        }

        QSlider#recordSeekSlider::add-page:horizontal {
            background: #1C2B4C;
            border-radius: 4px;
        }

        QSlider#recordSeekSlider::handle:horizontal {
            background: #FFFFFF;
            width: 14px;
            margin: -4px 0;
            border-radius: 7px;
        }

        QMenu {
            background-color: #111827;
            color: #FFFFFF;
            border: 1px solid #334155;
            padding: 6px;
        }

        QMenu::item {
            padding: 8px 20px;
            border-radius: 6px;
        }

        QMenu::item:selected {
            background-color: #2563EB;
        }
        """)
    # =========================
    # 聊天显示相关方法
    # =========================
    def append_user_message(self, text: str):
        """
        在聊天区追加用户消息
        """
        self.chat_display.append(f"<b>用户：</b>{text}")
        self.chat_display.append("")

    def append_ai_message(self, text: str):
        """
        在聊天区追加 AI 消息
        """
        self.chat_display.append(f"<b>AI：</b>{text}")
        self.chat_display.append("")

    def append_recognized_message(self, text: str):
        """
        在聊天区追加语音识别结果
        """
        self.chat_display.append(f"<b>语音识别：</b>{text}")
        self.chat_display.append("")

    def set_status(self, text: str):
        """
        更新底部状态文字
        """
        self.status_label.setText(f"状态：{text}")

    # =========================
    # 录音相关界面方法
    # =========================
    def reset_record_ui(self):
        """
        重置录音界面状态
        """
        self.record_seconds = 0
        self.record_progress.setValue(0)
        self.record_time_label.setText(f"录音时长：0 秒 / {self.max_record_seconds} 秒")
        self.record_status_label.setText("录音状态：未开始")
        

    def start_record_ui(self):
        """
        开始录音时更新页面状态
        """
        self.record_seconds = 0
        self.record_progress.setValue(0)
        self.record_status_label.setText("录音状态：录音中...")
        self.record_time_label.setText(f"录音时长：0 秒 / {self.max_record_seconds} 秒")

        self.start_record_btn.setEnabled(False)
        self.stop_record_btn.setEnabled(True)

        self.set_status("开始录音")
        self.record_timer.start(1000)

    def stop_record_ui(self):
        """
        停止录音时更新页面状态
        """
        self.record_timer.stop()
        self.start_record_btn.setEnabled(True)
        self.stop_record_btn.setEnabled(False)

        if self.record_seconds < self.min_record_seconds:
            self.record_status_label.setText("录音状态：录音过短")
            self.set_status("录音不足 2 秒，请重新录音")
        else:
            self.record_status_label.setText("录音状态：录音完成")
            self.set_status("录音完成，正在自动识别语音...")
            

    def update_record_progress(self):
        """
        每秒更新录音进度条与时间显示
        """
        self.record_seconds += 1
        self.record_progress.setValue(self.record_seconds)
        self.record_time_label.setText(
            f"录音时长：{self.record_seconds} 秒 / {self.max_record_seconds} 秒"
        )

        # 达到最长录音时间后自动停止
        if self.record_seconds >= self.max_record_seconds:
            self.record_timer.stop()
            self.record_status_label.setText("录音状态：已达到最大录音时长")
            self.set_status("已达到 60 秒上限，自动停止录音")
            self.on_stop_record_clicked()


    def init_speed_menu(self):
        self.speed_menu = QMenu(self)

        speed_options = [0.75, 1.0, 1.25, 1.5, 2.0, 3.0]
        for speed in speed_options:
            action = self.speed_menu.addAction(f"{speed}x")
            action.triggered.connect(lambda checked=False, s=speed: self.on_speed_menu_selected(s))

        self.speed_menu_btn.setMenu(self.speed_menu)


    # =========================
    # 外部可调用方法
    # =========================
    def set_recognized_text(self, text: str):
        """
        外部在识别完成后调用：
        1. 保存识别结果
        2. 显示到聊天区
        3. 写入输入框，方便再次编辑
        """
        self.current_recognized_text = text.strip()

        if self.current_recognized_text:
            self.append_recognized_message(self.current_recognized_text)
            self.set_status("语音识别完成")
        else:
            self.set_status("未识别到有效语音内容")
            

    def clear_page(self):
        """
        刷新页面内容：
        1. 清空聊天区
        2. 清空输入框
        3. 清空识别内容
        4. 重置录音状态
        """
        self.chat_display.clear()
        self.text_input.clear()
        self.current_recognized_text = ""
        self.reset_record_ui()
        self.speed_menu_btn.setText("1.0x")
        self.set_status("页面已刷新")

    # =========================
    # 按钮事件
    # =========================
    def on_send_text_clicked(self):
        """
        点击“发送文字”按钮
        """
        text = self.text_input.toPlainText().strip()
        if not text:
            QMessageBox.warning(self, "提示", "请输入文本内容后再发送。")
            return

        self.append_user_message(text)
        self.send_text_requested.emit(text)
        self.text_input.clear()
        self.set_status("已发送文字给 AI")

    def on_start_record_clicked(self):
        """
        点击“开始录音”按钮
        """
        self.start_record_ui()
        self.start_record_requested.emit()

    def on_stop_record_clicked(self):
        """
        点击“停止录音”按钮
        录音不足 2 秒时，不允许进入识别发送阶段
        """
        self.stop_record_requested.emit()
        self.stop_record_ui()

    def on_refresh_clicked(self):
        """
        点击“刷新页面”按钮
        这里只刷新界面内容，不关闭程序
        """
        self.clear_page()
        self.refresh_requested.emit()

    def on_exit_clicked(self):
        """
        点击“退出页面”按钮
        退出前发出结束任务信号，并关闭窗口
        """
        reply = QMessageBox.question(
            self,
            "确认退出",
            "退出后将结束当前系统任务，是否继续？",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.exit_requested.emit()
            self.close()
    
    def on_record_play_clicked(self):
        if self.record_is_playing:
            self.record_pause_requested.emit()
        else:
            self.record_play_requested.emit()

    def on_record_seek_released(self):
        if self.record_seek_slider.maximum() <= 0:
            return
        progress = self.record_seek_slider.value() / self.record_seek_slider.maximum()
        self.record_seek_requested.emit(progress)

    def on_speed_menu_selected(self, speed: float):
        self.record_speed = speed
        self.speed_menu_btn.setText(f"{speed}x")
        self.record_speed_changed.emit(speed)

    def set_record_playback_enabled(self, enabled: bool):
        self.record_play_btn.setEnabled(enabled)
        self.record_seek_slider.setEnabled(enabled)
        self.speed_menu_btn.setEnabled(enabled)

    def set_record_play_state(self, is_playing: bool):
        self.record_is_playing = is_playing
        self.record_play_btn.setText("⏸" if is_playing else "▶")

    def set_record_duration(self, total_ms: int):
        self.record_total_ms = max(0, total_ms)
        self.update_record_playback_ui(self.record_current_ms, self.record_total_ms)

    def update_record_playback_ui(self, current_ms: int, total_ms: int = None):
        if total_ms is not None:
            self.record_total_ms = max(0, total_ms)

        self.record_current_ms = max(0, current_ms)

        total = self.record_total_ms if self.record_total_ms > 0 else 1
        value = int(self.record_current_ms / total * 1000)
        value = max(0, min(value, 1000))

        self.record_seek_slider.blockSignals(True)
        self.record_seek_slider.setValue(value)
        self.record_seek_slider.blockSignals(False)

        self.record_time_preview_label.setText(
            f"{self.format_ms(self.record_current_ms)} / {self.format_ms(self.record_total_ms)}"
        )

    def format_ms(self, ms: int) -> str:
        seconds = max(0, int(ms / 1000))
        m = seconds // 60
        s = seconds % 60
        return f"{m}:{s:02d}"    