// 获取页面中的主要元素
const chatPanel = document.getElementById("chatPanel");
const textInput = document.getElementById("textInput");
const sendBtn = document.getElementById("sendBtn");
const startRecordBtn = document.getElementById("startRecordBtn");
const stopRecordBtn = document.getElementById("stopRecordBtn");
const transcribeBtn = document.getElementById("transcribeBtn");
const resetBtn = document.getElementById("resetBtn");
const refreshBtn = document.getElementById("refreshBtn");
const closeBtn = document.getElementById("closeBtn");
const statusText = document.getElementById("statusText");

// AI 回复播放器
const audioPlayer = document.getElementById("audioPlayer");

// 本地录音回放播放器
const recordPreviewPlayer = document.getElementById("recordPreviewPlayer");

// 识别文字显示区域
const recognizedText = document.getElementById("recognizedText");

// 录音器对象
let mediaRecorder = null;

// 录音数据块数组
let audioChunks = [];

// 当前麦克风流
let currentStream = null;

// 当前录好的音频 Blob，供“识别录音”和“语音聊天”复用
let recordedBlob = null;

// 本地预览 URL，用于释放资源
let localPreviewUrl = null;


/**
 * 更新页面状态文字
 */
function setStatus(text) {
    statusText.textContent = `状态：${text}`;
}


/**
 * 向聊天区域追加一条消息
 * @param {string} role - user 或 ai
 * @param {string} text - 要显示的文本
 */
function appendMessage(role, text) {
    const wrapper = document.createElement("div");
    wrapper.className = `message ${role}`;

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;

    wrapper.appendChild(bubble);
    chatPanel.appendChild(wrapper);
    chatPanel.scrollTop = chatPanel.scrollHeight;
}


/**
 * 发送文字消息到后端，让 AI 回复
 */
async function sendTextMessage() {
    const text = textInput.value.trim();

    if (!text) {
        alert("请输入内容");
        return;
    }

    appendMessage("user", text);
    textInput.value = "";
    setStatus("正在请求 AI 回复...");

    try {
        const response = await fetch("/chat_text", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ text })
        });

        const data = await response.json();

        if (!response.ok || data.error) {
            throw new Error(data.error || "请求失败");
        }

        appendMessage("ai", data.ai_text);

        // 如果后端返回了语音文件，则设置播放器
        if (data.audio_url) {
            audioPlayer.src = data.audio_url;

            // 根据配置决定是否自动播放
            if (data.auto_play) {
                audioPlayer.play().catch(() => {});
            }
        }

        setStatus("文字对话完成");
    } catch (error) {
        console.error(error);
        setStatus("发生错误");
        alert(error.message);
    }
}


/**
 * 开始录音
 */
async function startRecording() {
    try {
        // 获取麦克风音频流
        currentStream = await navigator.mediaDevices.getUserMedia({
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            }
        });

        console.log("已获取麦克风流:", currentStream);
        console.log("音轨信息:", currentStream.getAudioTracks());

        // 清空上一次录音数据
        audioChunks = [];
        recordedBlob = null;
        recognizedText.textContent = "暂无识别内容";

        // 如果上次有本地预览 URL，先释放
        if (localPreviewUrl) {
            URL.revokeObjectURL(localPreviewUrl);
            localPreviewUrl = null;
        }

        // 录音格式优先使用 webm + opus
        let options = {};
        if (MediaRecorder.isTypeSupported("audio/webm;codecs=opus")) {
            options.mimeType = "audio/webm;codecs=opus";
        } else if (MediaRecorder.isTypeSupported("audio/webm")) {
            options.mimeType = "audio/webm";
        }

        mediaRecorder = new MediaRecorder(currentStream, options);

        // 录音开始回调
        mediaRecorder.onstart = () => {
            console.log("录音已开始");
        };

        // 录音数据返回回调
        mediaRecorder.ondataavailable = (event) => {
            console.log("收到录音块大小:", event.data.size);
            if (event.data.size > 0) {
                audioChunks.push(event.data);
            }
        };

        // 录音异常回调
        mediaRecorder.onerror = (event) => {
            console.error("录音器错误:", event.error);
            setStatus("录音器错误");
        };

        // 每 1 秒产生一次录音块，方便调试
        mediaRecorder.start(1000);

        startRecordBtn.disabled = true;
        stopRecordBtn.disabled = false;
        transcribeBtn.disabled = true;
        setStatus("录音中...");
    } catch (error) {
        console.error(error);
        alert("无法访问麦克风，请检查浏览器权限和输入设备");
        setStatus("麦克风访问失败");
    }
}


/**
 * 停止录音
 * 停止后先不自动聊天，而是先生成本地回放，方便测试
 */
async function stopRecording() {
    if (!mediaRecorder) {
        return;
    }

    mediaRecorder.onstop = async () => {
        try {
            // 将录音块组合成最终音频
            recordedBlob = new Blob(audioChunks, { type: "audio/webm" });

            console.log("录音块数量:", audioChunks.length);
            console.log("最终录音文件大小:", recordedBlob.size);

            // 如果录音为空，直接提示
            if (recordedBlob.size === 0) {
                alert("录音数据为空，请检查麦克风设备或浏览器权限");
                setStatus("录音数据为空");
                return;
            }

            // 生成本地回放 URL，供用户试听录音
            localPreviewUrl = URL.createObjectURL(recordedBlob);
            recordPreviewPlayer.src = localPreviewUrl;

            // 启用“识别录音”按钮
            transcribeBtn.disabled = false;

            setStatus("录音完成，可先试听或识别文字");
        } catch (error) {
            console.error(error);
            alert("停止录音后处理失败");
            setStatus("录音处理失败");
        } finally {
            startRecordBtn.disabled = false;
            stopRecordBtn.disabled = true;

            // 关闭当前麦克风流
            if (currentStream) {
                currentStream.getTracks().forEach(track => track.stop());
                currentStream = null;
            }

            mediaRecorder = null;
        }
    };

    mediaRecorder.stop();
}


/**
 * 只识别录音，不进行 AI 对话
 * 识别完成后，将文字显示到页面，并自动填入输入框
 */
async function transcribeRecordedAudio() {
    if (!recordedBlob) {
        alert("请先录音");
        return;
    }

    try {
        setStatus("正在识别录音...");

        const formData = new FormData();
        formData.append("audio", recordedBlob, "record.webm");

        const response = await fetch("/transcribe_audio", {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (!response.ok || data.error) {
            throw new Error(data.error || "语音识别失败");
        }

        // 在页面显示识别结果
        recognizedText.textContent = data.user_text;

        // 自动填入输入框，方便用户继续修改或直接发送
        textInput.value = data.user_text;

        setStatus("语音识别完成");
    } catch (error) {
        console.error(error);
        alert(error.message);
        setStatus("语音识别失败");
    }
}


/**
 * 清空聊天记录
 */
async function resetChat() {
    try {
        const response = await fetch("/reset_chat", {
            method: "POST"
        });

        await response.json();

        chatPanel.innerHTML = "";
        audioPlayer.src = "";
        recognizedText.textContent = "暂无识别内容";
        textInput.value = "";

        // 清理本地录音预览
        if (localPreviewUrl) {
            URL.revokeObjectURL(localPreviewUrl);
            localPreviewUrl = null;
        }

        recordPreviewPlayer.src = "";
        recordedBlob = null;

        transcribeBtn.disabled = true;
        setStatus("会话已清空");
    } catch (error) {
        console.error(error);
        alert("清空会话失败");
    }
}


/**
 * 刷新页面
 */
function refreshPage() {
    window.location.reload();
}


/**
 * 关闭页面
 * 注意：如果不是脚本打开的窗口，部分浏览器可能会阻止关闭。
 */
function closePage() {
    window.close();

    // 某些浏览器不允许直接关闭普通标签页，这里做一个兜底处理
    setTimeout(() => {
        if (!window.closed) {
            alert("浏览器阻止了自动关闭，请手动关闭当前页面。");
        }
    }, 300);
}


// 绑定按钮事件
sendBtn.addEventListener("click", sendTextMessage);
startRecordBtn.addEventListener("click", startRecording);
stopRecordBtn.addEventListener("click", stopRecording);
transcribeBtn.addEventListener("click", transcribeRecordedAudio);
resetBtn.addEventListener("click", resetChat);
refreshBtn.addEventListener("click", refreshPage);
closeBtn.addEventListener("click", closePage);

// 输入框回车发送（Shift + Enter 换行）
textInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        sendTextMessage();
    }
});